A Pen created at CodePen.io. You can find this one at https://codepen.io/jannypie/pen/DcHdo.

 This is a basic template for one of those Buzzfeed-style personality quizzes, with flexible number of steps and results. Add, remove, or change possible results in the jQuery object 'resultOptions'. Layout is fluid responsive. There's a surprise at the end of the quiz!
Created in Sass with jQuery by Jan Dennison @jannypie